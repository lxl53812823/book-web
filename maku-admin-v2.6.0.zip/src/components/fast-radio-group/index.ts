import { withInstall } from '@/utils/tool'
import FastRadioGroup from './src/fast-radio-group.vue'

export default withInstall(FastRadioGroup)
