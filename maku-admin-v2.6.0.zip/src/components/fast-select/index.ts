import { withInstall } from '@/utils/tool'
import FastSelect from './src/fast-select.vue'

export default withInstall(FastSelect)
