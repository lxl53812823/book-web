import { withInstall } from '@/utils/tool'
import FastTableColumn from './src/fast-table-column.vue'

export default withInstall(FastTableColumn)
