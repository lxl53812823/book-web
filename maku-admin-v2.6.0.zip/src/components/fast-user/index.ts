import { withInstall } from '@/utils/tool'
import FastUser from './src/fast-user.vue'

export default withInstall(FastUser)
