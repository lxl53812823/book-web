import { withInstall } from '@/utils/tool'
import SvgIcon from './src/svg-icon.vue'

export default withInstall(SvgIcon)
