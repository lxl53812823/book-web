export default {
	profile: {
		username: 'Username',
		oldPassword: 'Original Password',
		newPassword: 'New Password',
		confirmPassword: 'Confirm Password'
	}
}
