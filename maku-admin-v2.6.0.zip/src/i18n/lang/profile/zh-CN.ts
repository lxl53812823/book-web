export default {
	profile: {
		username: '用户名',
		oldPassword: '原密码',
		newPassword: '新密码',
		confirmPassword: '确认密码'
	}
}
