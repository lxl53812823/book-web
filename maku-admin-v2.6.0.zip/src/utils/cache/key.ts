export default {
	SidebarOpenedKey: 'sidebarOpened',
	LangKey: 'lang',
	ComponentSizeKey: 'componentSize',
	TokenKey: 'maToken',
	RefreshTokenKey: 'maRefreshToken',
	ThemeKey: 'theme'
}
