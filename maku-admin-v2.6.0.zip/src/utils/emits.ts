import mitt, { Emitter } from 'mitt'

export default mitt() as Emitter<any>
